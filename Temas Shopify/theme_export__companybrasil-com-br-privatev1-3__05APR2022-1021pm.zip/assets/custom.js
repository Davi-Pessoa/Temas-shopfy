jQuery_T4NT(document).ready(function($) {
  // any code js
});